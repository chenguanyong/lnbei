Contains scaffold files for a new unit test setup.  Create a folder inside `unit` and copy `qunit.html` and `tests.js` into
it.